<?php

session_start();

if (!$_SESSION['admin']) {
	header("Location: admin_login.php");
}

?><!DOCTYPE html>
<html lang="en">

<head>
	<title>Admin Page</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:700,900" rel="stylesheet">
    <link href="assets/css/blog.css" rel="stylesheet">
</head>

<body>
	
	<h1 style="text-align: center">Welcome to Administrator Page</h1>
	<hr>
	
	<div style="text-align: center">
		<a href="index.php">View Site </a>| 
		<a href="admin_logout.php">Logout</a>
	</div>
	
	<hr>	
	
	<h3>Halaman administrasi blog</h3>
	
	<p>Coming soon...</p>
	
</body>

</html>
